# FenixLib

FenixLib is my Python library designed to provide various functionalities that i use often.

## Features

- **Returning paths**: Return a path to a file then add it to a config file so you dont need to select it everytime.
- **W.I.P.**: I will code more things and add to it everytime i need a new function to use more often.

## Installation

FenixLib can be installed via pip:

```bash
pip install fenixlib
